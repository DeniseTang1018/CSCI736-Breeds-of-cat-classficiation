package com.breedofcat;

public class Cat {
	
	private BodyType bodyType;
	private Continent continent;
	private Pattern pattern;
	private Country country;
	private Coat coat;
	private double coatL;
	private boolean evenColor;
	private boolean partialColor;
	private int numberofColor;
	private String shape;
	private Breed breed;
	
	

	public Cat(BodyType bodyType,Continent continent,double coatL,boolean evenColor, boolean partialColor, int numberofColor, String shape ) {
		this.bodyType = bodyType;
		this.continent = continent;
		this.coatL = coatL;
		this.evenColor = evenColor;
		this.numberofColor = numberofColor;
		this.partialColor = partialColor;
		this.shape = shape;
	}
	
		public Breed getBreed() {
		return breed;
	}


	public void setBreed(Breed breed) {
		this.breed = breed;
	}
	public String getShape() {
		return shape;
	}


	public void setShape(String shape) {
		this.shape = shape;
	}


	public int getNumberofColor() {
		return numberofColor;
	}
	
	public boolean isPartialColor() {
		return partialColor;
	}
	
	public boolean isEvenColor() {
		return evenColor;
	}
	
	public double getCoatL() {
		return coatL;
	}
	public void setCoatL(double coatL) {
		this.coatL = coatL;
	}
	public Coat getCoat() {
		return coat;
	}

	public void setCoat(Coat coat) {
		this.coat = coat;
	}

	public BodyType getBodyType() {
		return bodyType;
	}
	public void setBodyType(BodyType bodyType) {
		this.bodyType = bodyType;
	}
	public Continent getContinent() {
		return continent;
	}
	public void setContinent(Continent continent) {
		this.continent = continent;
	}
	public Pattern getPattern() {
		return pattern;
	}
	public void setPattern(Pattern pattern) {
		this.pattern = pattern;
	}
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	
	

}
