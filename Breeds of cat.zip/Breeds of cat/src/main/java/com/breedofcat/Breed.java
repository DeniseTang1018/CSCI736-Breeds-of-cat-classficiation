package com.breedofcat;

public enum Breed {

	TurkishAngora,
	Aegean,
	Sphynx,
	MaineCoon,
	NorwegianForest,
	AmericanCurl,
	Bengal,
	Bombay,
	Persian,
	BritishShorthair,
	JapaneseBobtail,
	ScottishFold,
	ExoticShorthair;
	
}
