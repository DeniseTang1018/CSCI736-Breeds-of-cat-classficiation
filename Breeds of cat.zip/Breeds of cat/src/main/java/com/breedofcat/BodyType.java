package com.breedofcat;

public enum BodyType {
	//SemiCobby,
	Oriental,
	Moderate,
	//LeanAndMuscular,
	Large,
	//Dwarf,
	Cobby,
	Empty;
}
