package com.breedofcat;

public enum Coat {
	
	Short,
	Long,
	SemiLong,
	//Rex,
	Hairless,
	PartlyHairless,
	//Medium,
	//Downy,
	All,
	//Null;
	
}
