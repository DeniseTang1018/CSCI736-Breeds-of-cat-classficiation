package com.breedofcat;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUIMain extends JFrame {

	private JPanel contentPane;
	private JTextField Q3textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUIMain frame = new GUIMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUIMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 909, 461);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel Q1Label = new JLabel("Q1: What is the body shape (type) of the cat?");
		
		JLabel Q2Label = new JLabel("Q2: What is the continent of the cat?");
		
		JLabel Q3Label = new JLabel("Q3: What is the coat length of the cat (scale 0-10 cm)?");
		
		JLabel Q4Label = new JLabel("Q4: If the color of the coat uniform?");
		
		JLabel Q5Label = new JLabel("Q5: If the color cover whole body?");
		
		JLabel Q6Label = new JLabel("Q6: How many numbers of color does it have?");
		
		JLabel Q7Label = new JLabel("Q7: what is the shape of the color fur?");
		
		JComboBox Q1comboBox = new JComboBox(BodyType.values());
		
		JComboBox Q2comboBox = new JComboBox(Continent.values());
		Boolean [] Q4 = {true,false};
		JComboBox Q4comboBox = new JComboBox(Q4);
		
		Q3textField = new JTextField();
		Q3textField.setText("0-10 cm");
		Q3textField.setColumns(10);
		Boolean [] Q5 = {true,false};
		JComboBox Q5comboBox = new JComboBox(Q5);
		Integer [] Q6 = {1,2,3};
		JComboBox Q6comboBox = new JComboBox(Q6);
		String [] Q7 = {"Round","Stripe","Block"};
		JComboBox Q7comboBox = new JComboBox(Q7);
		
		JButton SubmitButton = new JButton("Submit");
		SubmitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Cat cat = new Cat((BodyType)Q1comboBox.getSelectedItem(),(Continent)Q2comboBox.getSelectedItem(),Double.parseDouble(Q3textField.getText()),(boolean)Q4comboBox.getSelectedItem(),(boolean)Q5comboBox.getSelectedItem(),(int)Q6comboBox.getSelectedItem(),(String)Q7comboBox.getSelectedItem());
				try {
					// load up the knowledge base
					KieServices ks = KieServices.Factory.get();
			        KieContainer kContainer = ks.getKieClasspathContainer();
			        KieSession kSession = kContainer.newKieSession("ksession-rules");
			        
			        //Create objects
					kSession.insert(cat);
					
					System.out.println("************* Fire Rules **************");
			        kSession.fireAllRules(); 
			        //System.out.println("Country "+cat.getCountry());
			        //System.out.println("BodyType "+cat.getBodyType());
			        //System.out.println("Coat "+cat.getCoat());
			        //System.out.println("Continent "+cat.getContinent());
			        //System.out.println("Breed "+cat.getBreed());
			        System.out.println("************************************");
					}catch (Throwable t) {
			            t.printStackTrace();
			        }
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(23)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(SubmitButton)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							.addComponent(Q1Label)
							.addComponent(Q2Label)
							.addComponent(Q4Label)
							.addComponent(Q3Label)
							.addComponent(Q5Label)
							.addComponent(Q6Label)
							.addComponent(Q7Label)))
					.addGap(56)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Q7comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Q6comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Q5comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Q3textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Q4comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Q2comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Q1comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(454, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Q1Label)
						.addComponent(Q1comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(25)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Q2Label)
						.addComponent(Q2comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(24)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Q3textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Q3Label))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Q4Label)
						.addComponent(Q4comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Q5Label)
						.addComponent(Q5comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Q6Label)
						.addComponent(Q6comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(35)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(Q7comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Q7Label))
					.addPreferredGap(ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
					.addComponent(SubmitButton)
					.addGap(25))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
