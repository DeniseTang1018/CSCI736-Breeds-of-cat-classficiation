package com.breedofcat;

public enum Pattern {

	//Varied,
	//Van,
	//Ticked,
	//TabbyWithTicking,
	//StripedTabby,
	Striped,
	Marbled,
	//Rosetted,
	//Tabby,
	Spotted,
	Solid,
	Hairless,
	//EvenlySolid,
	Colorprint,
	//Mitted,
	Bicolor,
	//Mink,
	Tricolored,
	AllButColorpoint,
	AllButSolid,
	AllButSpotted,
	//AllButCinammon,
	//Chocolate,
	All;
	//Null;
	
}
