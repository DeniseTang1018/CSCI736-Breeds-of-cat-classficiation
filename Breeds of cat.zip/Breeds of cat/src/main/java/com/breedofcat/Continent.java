package com.breedofcat;

public enum Continent {

	Asia,
	Europe,
	NorthAmerica,
	//SouthAmerica,
	//Africa,
	//Oceania,
	//Antarctica;
}
