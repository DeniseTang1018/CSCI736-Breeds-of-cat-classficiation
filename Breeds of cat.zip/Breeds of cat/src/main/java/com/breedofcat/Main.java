package com.breedofcat;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
		// load up the knowledge base
		KieServices ks = KieServices.Factory.get();
        KieContainer kContainer = ks.getKieClasspathContainer();
        KieSession kSession = kContainer.newKieSession("ksession-rules");
        
        //Create objects
		Cat cat = new Cat(BodyType.Empty,Continent.Asia,2, true,true,2,"Block");
		kSession.insert(cat);
		
		System.out.println("************* Fire Rules **************");
        kSession.fireAllRules(); 
        System.out.println(cat.getCountry());
        System.out.println(cat.getBodyType());
        System.out.println(cat.getCoat());
        System.out.println(cat.getBreed());
        System.out.println("************************************");
		}catch (Throwable t) {
            t.printStackTrace();
        }
	}

}
